// Fill out your copyright notice in the Description page of Project Settings.


#include "ProjectileBase.h"
#include "Components/StaticMeshComponent.h"
#include "GameFramework/ProjectileMovementComponent.h"
#include "FTTPlayerCharacter.h"
#include "Kismet/GameplayStatics.h"
#include "GravityMoveComponent.h"

// Sets default values
AProjectileBase::AProjectileBase()
{
	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = false;

	ProjectileMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BulletMesh"));
	RootComponent = ProjectileMesh;
	
	ProjectileMovement = CreateDefaultSubobject<UProjectileMovementComponent>(TEXT("Bullet Movement"));
	ProjectileMovement->InitialSpeed = MovementSpeed;
	ProjectileMovement->MaxSpeed = MovementSpeed;
	InitialLifeSpan = 3.0f; // 3���� �ش� Actor �ı�
}

void AProjectileBase::OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& hit)
{
	AActor* MyOwner = GetOwner();
	
	if(!MyOwner)
		return;

	if(OtherActor && OtherActor != this && OtherActor != MyOwner)
	{
		UGravityMoveComponent* GravityMoveComponent = OtherActor->FindComponentByClass<UGravityMoveComponent>();
		if(GravityMoveComponent)
		{
			// �浹 �� �̵� ó��
			GravityMoveComponent->SetStateMove();
			switch(bulletType)
			{
			case BulletType::UP:
				GravityMoveComponent->SetMoveDirection(gravityEffectSpeed, OtherActor->GetActorUpVector());
				break;
			case BulletType::DOWN:
				GravityMoveComponent->SetMoveDirection(-gravityEffectSpeed, OtherActor->GetActorUpVector());
				break;
			case BulletType::LEFT:
				GravityMoveComponent->SetMoveDirection(-gravityEffectSpeed, OtherActor->GetActorRightVector());
				break;
			case BulletType::RIGHT:
				GravityMoveComponent->SetMoveDirection(gravityEffectSpeed, OtherActor->GetActorRightVector());
				break;
			case BulletType::FORWARD:
				GravityMoveComponent->SetMoveDirection(gravityEffectSpeed, OtherActor->GetActorForwardVector());
				break;
			case BulletType::BACKWARD:
				GravityMoveComponent->SetMoveDirection(-gravityEffectSpeed, OtherActor->GetActorForwardVector());
				break;
			}
		}
		// �Ѿ� ��ź ȿ�� ����
		UGameplayStatics::SpawnEmitterAtLocation(GetWorld(),ImpactEffect, hit.Location, NormalImpulse.Rotation());
		// �Ѿ� ��ź ������ ��ź �Ҹ� ����
		UGameplayStatics::SpawnSoundAtLocation(GetWorld(), ImpactSound, hit.Location);
	}
	Destroy();
	
}


// Called when the game starts or when spawned
void AProjectileBase::BeginPlay()
{
	Super::BeginPlay();

	// Binding
	ProjectileMesh->OnComponentHit.AddDynamic(this, &AProjectileBase::OnHit);
}

// Called every frame
void AProjectileBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AProjectileBase::SetBulletType(BulletType type)
{
	bulletType = type;
}



