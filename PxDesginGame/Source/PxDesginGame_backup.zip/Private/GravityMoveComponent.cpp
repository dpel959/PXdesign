// Fill out your copyright notice in the Description page of Project Settings.


#include "GravityMoveComponent.h"

// Sets default values for this component's properties
UGravityMoveComponent::UGravityMoveComponent()
{
	// Set this component to be initialized when the game starts, and to be ticked every frame.  You can turn these features
	// off to improve performance if you don't need them.
	PrimaryComponentTick.bCanEverTick = true;

	// ...
}


// Called when the game starts
void UGravityMoveComponent::BeginPlay()
{
	Super::BeginPlay();

	
	
}


// Called every frame
void UGravityMoveComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	switch (currentState)
	{
		case EState::IDLE:
		{
			break;	
		}
		case EState::MOVE:
		{
			AActor* OwnerActor = GetOwner();
			FVector CurrentLocation = OwnerActor->GetActorLocation();
			FVector TargetLocation = CurrentLocation + direction * speed;
			OwnerActor->SetActorLocation(FMath::VInterpTo(CurrentLocation, TargetLocation, DeltaTime, 1.0f));
		}
		
	}
	
}

void UGravityMoveComponent::SetStateIdle()
{
	currentState = EState::IDLE;
}

void UGravityMoveComponent::SetStateMove()
{
	currentState = EState::MOVE;

	GetWorld()->GetTimerManager().SetTimer(GravityMoveTimerHandle, this, &UGravityMoveComponent::SetStateIdle, 3.0f);
}

void UGravityMoveComponent::SetMoveDirection(float _speed, FVector _direction)
{
	speed = _speed;
	direction = _direction;
}
