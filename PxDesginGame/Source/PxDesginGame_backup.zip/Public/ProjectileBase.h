// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ProjectileBase.generated.h"

class UStaticMeshComponent;
class UProjectileMovementComponent;


UENUM()
enum class BulletType
{
	UP,
	DOWN,
	RIGHT,
	LEFT,
	FORWARD,
	BACKWARD,
};

UCLASS()
class PXDESGINGAME_API AProjectileBase : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	AProjectileBase();

        // Called every frame
	virtual void Tick(float DeltaTime) override;

	void SetBulletType(BulletType type);

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

private:
	// Function
	UFUNCTION()
	void OnHit(UPrimitiveComponent* HitComponent, AActor* OtherActor, UPrimitiveComponent* OtherComp, FVector NormalImpulse, const FHitResult& hit);

	void SetGravity();
	
	// Variable
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Components", meta=(AllowPrivateAccess="true"))
	UProjectileMovementComponent* ProjectileMovement;
	
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category="Components", meta=(AllowPrivateAccess="true"))
	UStaticMeshComponent* ProjectileMesh;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Damage", meta=(AllowPrivateAccess="true"))
	TSubclassOf<UDamageType> DamageType;

	UPROPERTY(EditAnywhere)
	UParticleSystem* ImpactEffect;

	UPROPERTY(EditAnywhere)
	USoundBase* ImpactSound;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category="Damage", meta=(AllowPrivateAccess="true"))
	float MovementSpeed = 1300.0;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category="Damage", meta=(AllowPrivateAccess="true"))
	float Damage = 50.0;

	UPROPERTY(EditAnywhere, Category="Bullet Type", meta=(AllowPrivateAccess="true"))
	BulletType bulletType = BulletType::UP;

	UPROPERTY(EditAnywhere)
	float gravityEffectSpeed = 400.0f;
	

};
